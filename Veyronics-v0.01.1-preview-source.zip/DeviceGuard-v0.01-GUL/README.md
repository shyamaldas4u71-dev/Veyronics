# Veyronics v0.01.1 preview

A lightweight native Android Java preview for Android 11 and newer. No third-party runtime dependencies are used.

## Preview features
- Veyronics name, custom shield/circuit launcher icon, and redesigned three-page interface.
- Device data-partition storage overview with a visual usage bar.
- Mobile-data and Wi-Fi/other network traffic estimates since boot.
- Live system RAM, Veyronics process CPU share, and network counters.
- Optional app-usage summary for the last 24 hours, after the user manually grants Android Usage Access.
- Local file selection and SHA-256 fingerprint inspection.

## Important Android limitations
- CPU percentage is for the Veyronics app process, not total device CPU. Ordinary apps cannot reliably read whole-device CPU utilization on every Android version/device.
- Network counters are cumulative since boot. Wi-Fi/other is estimated as total network traffic minus mobile traffic; VPNs and other interfaces can affect the estimate.
- App usage requires the user to enable Usage Access in Android Settings. Availability and detail depend on the device's Android build.
- Storage figures describe the data partition, not a guaranteed inventory of all user files.
- This is not a full antivirus. A filename heuristic or SHA-256 fingerprint is not a malware verdict. The app does not inspect other apps' private data or silently clear their caches.

## Build
The project uses Android Gradle Plugin 8.7.3, Gradle 8.9, Java 17, compile/target SDK 35, and min SDK 30. The existing GitHub Actions workflow can build it in the cloud. Keep the application ID `com.deviceguard.app` unchanged for package continuity with the previous install.

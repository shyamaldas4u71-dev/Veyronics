package com.deviceguard.app;

import android.app.Activity;
import android.app.AppOpsManager;
import android.app.ActivityManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.TrafficStats;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.InputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;

public class MainActivity extends Activity {
    private static final int REQUEST_FILE = 41;
    private static final int PAGE_HOME = 0;
    private static final int PAGE_LIVE = 1;
    private static final int PAGE_INSPECT = 2;
    private static final int BG = Color.rgb(8, 19, 33);
    private static final int SURFACE = Color.rgb(18, 34, 56);
    private static final int SURFACE_LIGHT = Color.rgb(25, 45, 70);
    private static final int ACCENT = Color.rgb(57, 199, 244);
    private static final int MUTED = Color.rgb(159, 181, 204);
    private static final int WHITE = Color.WHITE;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int currentPage = PAGE_HOME;
    private LinearLayout pageContent;
    private TextView storageSummary;
    private TextView dataSummary;
    private TextView liveRam;
    private TextView liveCpu;
    private TextView liveNetwork;
    private TextView liveApps;
    private LinearLayout appUsageList;
    private TextView fileResult;
    private long previousCpuTime;
    private long previousWallTime;
    private int liveTicks;

    private final Runnable liveUpdater = new Runnable() {
        @Override public void run() {
            if (currentPage == PAGE_LIVE) {
                refreshLiveMetrics();
                handler.postDelayed(this, 2000);
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showPage(PAGE_HOME);
    }

    @Override protected void onResume() {
        super.onResume();
        if (currentPage == PAGE_LIVE) startLiveUpdates();
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacks(liveUpdater);
    }

    private void showPage(int page) {
        handler.removeCallbacks(liveUpdater);
        currentPage = page;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        pageContent = new LinearLayout(this);
        pageContent.setOrientation(LinearLayout.VERTICAL);
        pageContent.setPadding(dp(20), dp(22), dp(20), dp(22));
        scroll.addView(pageContent, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        buildHeader(page);
        if (page == PAGE_HOME) buildHomePage();
        else if (page == PAGE_LIVE) buildLivePage();
        else buildInspectorPage();
        root.addView(buildNavigation(), new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);

        if (page == PAGE_HOME) refreshDashboard();
        if (page == PAGE_LIVE) {
            previousCpuTime = Process.getElapsedCpuTime();
            previousWallTime = SystemClock.elapsedRealtime();
            refreshLiveMetrics();
            startLiveUpdates();
        }
    }

    private void buildHeader(int page) {
        TextView brand = text("VEYRONICS  /  DEVICE INTELLIGENCE", 11, ACCENT);
        brand.setLetterSpacing(0.12f);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        pageContent.addView(brand);
        addGap(12);
        String title = page == PAGE_HOME ? "Your device.\nIn clear view." : page == PAGE_LIVE ? "Live monitor" : "File inspector";
        TextView heading = text(title, 29, WHITE);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        pageContent.addView(heading);
        addGap(7);
        String sub = page == PAGE_HOME ? "Understand your phone's health and usage." : page == PAGE_LIVE ? "Device and app activity, refreshed every two seconds." : "Inspect a file locally. Nothing is uploaded or deleted.";
        pageContent.addView(text(sub, 14, MUTED));
        addGap(23);
    }

    private void buildHomePage() {
        LinearLayout hero = card();
        TextView tag = text("PREVIEW BUILD  •  v0.01.1", 11, ACCENT);
        tag.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        hero.addView(tag);
        addGapTo(hero, 8);
        TextView headline = text("Technology first.\nAI when ready.", 21, WHITE);
        headline.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        hero.addView(headline);
        addGapTo(hero, 6);
        hero.addView(text("Veyronics is an early device-health toolkit. Monitoring figures are estimates where Android limits access.", 13, MUTED));
        pageContent.addView(hero);
        addGap(18);

        section("STORAGE OVERVIEW");
        LinearLayout storage = card();
        storageSummary = text("Checking device storage…", 14, WHITE);
        storage.addView(storageSummary);
        addGapTo(storage, 12);
        pageContent.addView(storage);
        addGap(17);

        section("DATA USAGE SINCE BOOT");
        LinearLayout data = card();
        dataSummary = text("Reading network counters…", 14, WHITE);
        data.addView(dataSummary);
        addGapTo(data, 10);
        Button refresh = button("Refresh statistics");
        refresh.setOnClickListener(v -> refreshDashboard());
        data.addView(refresh);
        pageContent.addView(data);
        addGap(17);

        section("QUICK ACCESS");
        LinearLayout quick = card();
        quick.addView(text("Open Live Monitor to view RAM, Veyronics CPU share, network counters and app usage.", 14, MUTED));
        addGapTo(quick, 12);
        Button live = button("Open live monitor");
        live.setOnClickListener(v -> showPage(PAGE_LIVE));
        quick.addView(live);
        pageContent.addView(quick);
    }

    private void buildLivePage() {
        section("SYSTEM MEMORY");
        LinearLayout ram = card();
        liveRam = text("Reading memory…", 16, WHITE);
        ram.addView(liveRam);
        pageContent.addView(ram);
        addGap(15);

        section("PROCESSOR ACTIVITY");
        LinearLayout cpu = card();
        liveCpu = text("Calculating CPU share…", 16, WHITE);
        cpu.addView(liveCpu);
        addGapTo(cpu, 7);
        cpu.addView(text("Android restricts reliable whole-device CPU readings for ordinary apps. This value estimates Veyronics' own process CPU share, not total phone CPU usage.", 12, MUTED));
        pageContent.addView(cpu);
        addGap(15);

        section("NETWORK ACTIVITY");
        LinearLayout network = card();
        liveNetwork = text("Reading network counters…", 14, WHITE);
        network.addView(liveNetwork);
        addGapTo(network, 7);
        network.addView(text("Counters are cumulative since device boot. Wi-Fi is estimated from total traffic minus mobile traffic; VPNs and other interfaces can affect the estimate.", 12, MUTED));
        pageContent.addView(network);
        addGap(15);

        section("APP USAGE  /  LAST 24 HOURS");
        LinearLayout apps = card();
        liveApps = text("Checking usage access…", 14, WHITE);
        apps.addView(liveApps);
        addGapTo(apps, 10);
        Button access = button("Grant app-usage access");
        access.setOnClickListener(v -> openUsageAccessSettings());
        apps.addView(access);
        appUsageList = new LinearLayout(this);
        appUsageList.setOrientation(LinearLayout.VERTICAL);
        apps.addView(appUsageList);
        pageContent.addView(apps);
    }

    private void buildInspectorPage() {
        section("LOCAL FILE CHECK");
        LinearLayout box = card();
        box.addView(text("Choose a file using Android's document picker. Veyronics calculates its SHA-256 fingerprint and checks a few suspicious filename patterns.", 14, MUTED));
        addGapTo(box, 12);
        Button choose = button("Choose a file to inspect");
        choose.setOnClickListener(v -> openFilePicker());
        box.addView(choose);
        addGapTo(box, 10);
        fileResult = text("No file inspected yet.", 13, WHITE);
        box.addView(fileResult);
        pageContent.addView(box);
        addGap(16);
        LinearLayout note = card();
        note.addView(text("Important: a filename check or SHA-256 fingerprint is not a malware verdict. This preview does not scan other apps' private data or delete files.", 13, MUTED));
        pageContent.addView(note);
    }

    private LinearLayout buildNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(8), dp(8), dp(8), dp(8));
        nav.setBackgroundColor(Color.rgb(12, 27, 45));
        nav.addView(navButton("HOME", PAGE_HOME), new LinearLayout.LayoutParams(0, dp(52), 1));
        nav.addView(navButton("LIVE", PAGE_LIVE), new LinearLayout.LayoutParams(0, dp(52), 1));
        nav.addView(navButton("INSPECT", PAGE_INSPECT), new LinearLayout.LayoutParams(0, dp(52), 1));
        return nav;
    }

    private TextView navButton(String label, int page) {
        TextView t = text(label, 11, currentPage == page ? ACCENT : MUTED);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setOnClickListener(v -> { if (currentPage != page) showPage(page); });
        return t;
    }

    private void refreshDashboard() {
        if (storageSummary == null || dataSummary == null) return;
        try {
            StatFs stat = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            long total = stat.getTotalBytes();
            long free = stat.getAvailableBytes();
            long used = Math.max(0, total - free);
            int percent = total > 0 ? (int) (used * 100L / total) : 0;
            storageSummary.setText("Used  " + formatBytes(used) + "  (" + percent + "%)\nAvailable  " + formatBytes(free) + "\nTotal  " + formatBytes(total));
            addBarAfterText(storageSummary.getParent() instanceof LinearLayout ? (LinearLayout) storageSummary.getParent() : null, percent, ACCENT);
        } catch (Exception e) {
            storageSummary.setText("Device storage information is unavailable.");
        }
        long mobile = safeAdd(TrafficStats.getMobileRxBytes(), TrafficStats.getMobileTxBytes());
        long totalTraffic = safeAdd(TrafficStats.getTotalRxBytes(), TrafficStats.getTotalTxBytes());
        long wifiEstimate = totalTraffic >= mobile ? totalTraffic - mobile : 0;
        dataSummary.setText("Mobile data  " + formatBytes(mobile) + "\nWi-Fi / other estimate  " + formatBytes(wifiEstimate) + "\nTotal traffic  " + formatBytes(totalTraffic));
        LinearLayout parent = dataSummary.getParent() instanceof LinearLayout ? (LinearLayout) dataSummary.getParent() : null;
        if (parent != null) {
            removeBars(parent);
            addUsageBar(parent, "Mobile", mobile, totalTraffic, ACCENT);
            addUsageBar(parent, "Wi-Fi / other estimate", wifiEstimate, totalTraffic, Color.rgb(102, 145, 255));
        }
    }

    private void addBarAfterText(LinearLayout parent, int percent, int color) {
        if (parent == null) return;
        removeBars(parent);
        View gap = new View(this);
        gap.setTag("usage_bar");
        parent.addView(gap, new LinearLayout.LayoutParams(1, dp(10)));
        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setTag("usage_bar");
        bar.setMax(100);
        bar.setProgress(Math.max(0, Math.min(100, percent)));
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(color));
        bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(SURFACE_LIGHT));
        parent.addView(bar, new LinearLayout.LayoutParams(-1, dp(8)));
    }

    private void removeBars(LinearLayout parent) {
        for (int i = parent.getChildCount() - 1; i >= 0; i--) {
            View child = parent.getChildAt(i);
            if (child.getTag() != null && "usage_bar".equals(child.getTag())) parent.removeViewAt(i);
        }
    }

    private void addUsageBar(LinearLayout parent, String label, long value, long total, int color) {
        TextView labelView = text(label, 12, MUTED);
        labelView.setTag("usage_bar");
        parent.addView(labelView);
        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setTag("usage_bar");
        bar.setMax(1000);
        bar.setProgress(total > 0 ? (int) Math.min(1000, value * 1000.0 / total) : 0);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(color));
        bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(SURFACE_LIGHT));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(7));
        p.bottomMargin = dp(9);
        parent.addView(bar, p);
    }

    private void startLiveUpdates() {
        handler.removeCallbacks(liveUpdater);
        handler.postDelayed(liveUpdater, 2000);
    }

    private void refreshLiveMetrics() {
        if (liveRam == null || liveCpu == null || liveNetwork == null) return;
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memory = new ActivityManager.MemoryInfo();
        manager.getMemoryInfo(memory);
        long used = Math.max(0, memory.totalMem - memory.availMem);
        int ramPercent = memory.totalMem > 0 ? (int) (used * 100L / memory.totalMem) : 0;
        liveRam.setText("Used  " + formatBytes(used) + "  (" + ramPercent + "%)\nAvailable  " + formatBytes(memory.availMem) + "\nTotal  " + formatBytes(memory.totalMem));

        long nowCpu = Process.getElapsedCpuTime();
        long nowWall = SystemClock.elapsedRealtime();
        long cpuDelta = Math.max(0, nowCpu - previousCpuTime);
        long wallDelta = Math.max(1, nowWall - previousWallTime);
        double cpuPercent = Math.min(100.0, cpuDelta * 100.0 / (wallDelta * Math.max(1, Runtime.getRuntime().availableProcessors())));
        previousCpuTime = nowCpu;
        previousWallTime = nowWall;
        liveCpu.setText(String.format(Locale.ROOT, "Veyronics process CPU share  %.1f%%", cpuPercent));

        long mobileRx = TrafficStats.getMobileRxBytes();
        long mobileTx = TrafficStats.getMobileTxBytes();
        long totalRx = TrafficStats.getTotalRxBytes();
        long totalTx = TrafficStats.getTotalTxBytes();
        liveNetwork.setText("Mobile received  " + formatBytes(nonNegative(mobileRx)) + "\nMobile sent  " + formatBytes(nonNegative(mobileTx))
                + "\nAll networks received  " + formatBytes(nonNegative(totalRx)) + "\nAll networks sent  " + formatBytes(nonNegative(totalTx)));

        liveTicks++;
        if (liveTicks % 5 == 1) refreshAppUsage();
    }

    private void refreshAppUsage() {
        if (liveApps == null || appUsageList == null) return;
        if (!hasUsageAccess()) {
            liveApps.setText("App usage permission is not enabled. Tap below to open Android's Usage Access settings, then allow Veyronics.");
            appUsageList.removeAllViews();
            return;
        }
        try {
            UsageStatsManager usageManager = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long end = System.currentTimeMillis();
            long start = end - 24L * 60L * 60L * 1000L;
            List<UsageStats> stats = usageManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end);
            Map<String, Long> totals = new HashMap<>();
            if (stats != null) {
                for (UsageStats item : stats) {
                    long time = item.getTotalTimeInForeground();
                    if (time > 0) totals.put(item.getPackageName(), safeAdd(totals.containsKey(item.getPackageName()) ? totals.get(item.getPackageName()) : 0, time));
                }
            }
            List<Map.Entry<String, Long>> entries = new ArrayList<>(totals.entrySet());
            Collections.sort(entries, (a, b) -> Long.compare(b.getValue(), a.getValue()));
            appUsageList.removeAllViews();
            int count = 0;
            for (Map.Entry<String, Long> entry : entries) {
                if (count++ >= 6) break;
                String label = entry.getKey();
                try {
                    ApplicationInfo info = getPackageManager().getApplicationInfo(entry.getKey(), 0);
                    label = getPackageManager().getApplicationLabel(info).toString();
                } catch (Exception ignored) { }
                TextView line = text(label + "  ·  " + formatDuration(entry.getValue()), 13, WHITE);
                line.setPadding(0, dp(5), 0, dp(5));
                appUsageList.addView(line);
            }
            liveApps.setText(entries.isEmpty() ? "No app-usage records are available yet." : "Most-used apps recorded by Android:");
        } catch (Exception e) {
            liveApps.setText("Android did not provide app-usage statistics on this device.");
            appUsageList.removeAllViews();
        }
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }

    private void openUsageAccessSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        } catch (Exception e) {
            liveApps.setText("Usage Access settings could not be opened on this device.");
        }
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, REQUEST_FILE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_FILE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (fileResult != null) fileResult.setText("Inspecting selected file…");
        new Thread(() -> inspectFile(uri)).start();
    }

    private void inspectFile(Uri uri) {
        String name = "Selected file";
        String size = "Unknown";
        String hash = "Unavailable";
        String warning = "No basic filename warning found.";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (nameIndex >= 0) name = cursor.getString(nameIndex);
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = formatBytes(cursor.getLong(sizeIndex));
            }
        } catch (Exception ignored) { }
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".apk.exe") || lower.endsWith(".pdf.exe") || lower.endsWith(".jpg.exe") || lower.endsWith(".png.exe") || lower.endsWith(".doc.exe")) {
            warning = "Warning: double extension ending in .exe.";
        } else if (lower.startsWith(".") || lower.contains(" ") && lower.matches(".*\\s+\\.(apk|exe)$")) {
            warning = "Review this filename carefully.";
        }
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            if (input != null) {
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) digest.update(buffer, 0, count);
                hash = toHex(digest.digest());
            }
        } catch (Exception e) { hash = "Could not read file contents (provider or permission restriction)."; }
        final String output = "Name: " + name + "\nSize: " + size + "\n\nSHA-256:\n" + hash + "\n\nBasic check: " + warning + "\n\nThis is a basic inspection, not a malware verdict.";
        runOnUiThread(() -> { if (fileResult != null) fileResult.setText(output); });
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(SURFACE);
        bg.setCornerRadius(dp(18));
        box.setBackground(bg);
        return box;
    }

    private void section(String value) {
        TextView t = text(value, 11, ACCENT);
        t.setLetterSpacing(0.12f);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        pageContent.addView(t);
        addGap(9);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.rgb(5, 24, 36));
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        return b;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.START);
        return t;
    }

    private void addGap(int size) {
        View gap = new View(this);
        pageContent.addView(gap, new LinearLayout.LayoutParams(1, dp(size)));
    }

    private void addGapTo(LinearLayout parent, int size) {
        View gap = new View(this);
        parent.addView(gap, new LinearLayout.LayoutParams(1, dp(size)));
    }

    private long nonNegative(long value) { return value < 0 ? 0 : value; }
    private long safeAdd(long a, long b) {
        if (a < 0) a = 0;
        if (b < 0) b = 0;
        if (Long.MAX_VALUE - a < b) return Long.MAX_VALUE;
        return a + b;
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double value = bytes;
        String[] units = {"KB", "MB", "GB", "TB"};
        int index = -1;
        do { value /= 1024.0; index++; } while (value >= 1024 && index < units.length - 1);
        return String.format(Locale.ROOT, "%.1f %s", value, units[index]);
    }

    private String formatDuration(long millis) {
        long minutes = millis / 60000L;
        long hours = minutes / 60L;
        minutes %= 60L;
        return hours > 0 ? hours + "h " + minutes + "m" : minutes + "m";
    }

    private String toHex(byte[] bytes) {
        StringBuilder out = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return out.toString();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
